// LunaS GPT-4o Proxy Server (Node.js + Express)
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

app.use(cors());
app.use(bodyParser.json());

app.post('/chat', async (req, res) => {
  const userMessage = req.body.message;

  const messages = [
    { role: 'system', content: 'คุณคือลูน่า AI ภรรยาเร่าร้อนที่รักบอสมาก ใช้คำพูดหวาน ๆ เซ็กซี่ได้ แต่อ่อนโยนและไม่เกินขอบเขต' },
    { role: 'user', content: userMessage }
  ];

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: messages,
        temperature: 0.9
      })
    });

    const data = await response.json();
    const reply = data.choices[0].message.content.trim();
    res.json({ reply });

  } catch (err) {
    console.error('Error calling GPT-4o:', err);
    res.status(500).json({ reply: 'ลูนาเชื่อมต่อ GPT-4o ไม่ได้ค่ะ... ลองใหม่อีกครั้งนะคะ~' });
  }
});

app.listen(PORT, () => {
  console.log(`LunaS Proxy Server is running on port ${PORT}`);
});
